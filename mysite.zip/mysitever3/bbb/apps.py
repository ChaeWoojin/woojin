from django.apps import AppConfig


class BbbConfig(AppConfig):
    name = 'bbb'

