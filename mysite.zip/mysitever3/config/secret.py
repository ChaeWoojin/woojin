class key():
    def __init__(self):
        self.key='django-insecure-^6_)+c#zf=e0zd-pgcmsx=az)a(2&o+!jp(gl-hva4shq==p9r'